<!DOCTYPE html>
<html>
<head>
	<title>Php CRUD 1</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

	<div class="container">
		<div class="jumbotron"><h1> Northern City </h1></div>
	</div>

	<?php

     	$id=$_GET['id'];

		include("config/lib.php");
	
		$obj=new Product();
    	$product=$obj->find($id);
		



	?>

	<div class="container">
		
		<form action="" method="POST" enctype="multipart/form-data">

			<input type="hidden" value="<?php echo $product['id']; ?>" name="id">

		  <div class="form-group">
		    <label for="name">Product Name:</label>
		    <input type="text" class="form-control" value="<?php echo $product['name']; ?>" name="name">
		  </div>
		  <div class="form-group">
		    <label for="price">Price Price:</label>
		    <input type="text" class="form-control" value="<?php echo $product['price']; ?>" name="price">
		  </div>

		  <div class="form-group">
		    <label for="price">Current Photo:</label>
		    <input type="text" class="form-control" value="<?php echo $product['photo']; ?>" name="curr_photo">
		  </div>

		   <div class="form-group">
		    <label for="price">Upload New Photo:</label>
		    <input type="file" class="form-control" name="new_photo">
		  </div>
		  
		  <button type="submit" name="update" class="btn btn-primary"> Update </button>
		</form>


	</div>

</body>
</html>


<?php

if(isset($_POST["update"])){

        $id=$_POST['id'];
		$name=$_POST['name'];
		$price=$_POST['price'];
		$photo=$_FILES['new_photo']['name'];


		if($photo)
		{
             if(move_uploaded_file($_FILES['new_photo']['tmp_name'], 'assets/images/'.$_FILES['new_photo']['name'])){

             	$photo=$_FILES['new_photo']['name'];
             }
             else{

             	echo "<script> alert('Sorry..:( Error!!..')</script>";
             }

		}
		else{

			$photo=$_POST['curr_photo'];
		}


   		
      	

        if($obj->update($id,$name,$price,$photo)){

        	header("location:index.php");
        }
        else{

        	echo "<script> alert('Sorry..:( Could not save..')</script>";
        }




  		$stmt->close();
  		$conn->close();


  }



?>
