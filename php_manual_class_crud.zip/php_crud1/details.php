<!DOCTYPE html>
<html>
<head>
	<title>Php CRUD 1</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

	<div class="container">
		<div class="jumbotron"><h1> Northern City </h1></div>
	</div>

	<div class="container" style="font-size: 22px;color:blue;font-weight: bold;">
		<a href="index.php"> Home </a> >> Details
	</div>

	<?php
     $id=$_GET['id'];

	include("config/lib.php");
	
	$obj=new Product();
    $product=$obj->find($id);
     

	?>


	<div class="container">
		
		   <div class="form-group">
		  
		    <img src="assets/images/<?php echo $product['photo']; ?>" class="rounded-circle" style="width:300px;height:300px;" >
		  </div>
		  <div class="form-group">
		    <label for="name">Product Name:</label>
		    <div style="font-size:40px;color:orange"> <?php echo $product['name']; ?> </div>
		  </div>
		  <div class="form-group">
		    <label for="price">Product Price:</label>
		   <div style="font-size:40px;color:orange"> <?php echo $product['price']; ?> </div>
		  </div>
		  
		  
		


	</div>

</body>
</html>