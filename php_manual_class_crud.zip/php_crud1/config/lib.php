<?php



class Product{


	public function index()
	{
		include("db.php");
		$products=$conn->query("select * from products")->fetchAll();
		return $products;

	}

	public function find($id)
	{
        include("db.php");
		$product=$conn->query("select * from products where id=$id")->fetch();
		return $product;


	}

	public function update($id,$name,$price,$photo)
	{
         include("db.php");
         $sql = "UPDATE products SET name='$name', price=$price,photo='$photo' WHERE id=$id";

         $stmt = $conn->prepare($sql);

         if($stmt->execute())
         	return true;
         else
         	return false;

	}


	public function destroy($id)
	{
          include("db.php");
          $res=$conn->query("delete from products where id=$id");

          if($res)
          	return true;
          else
          	return false;

	}




}











?>