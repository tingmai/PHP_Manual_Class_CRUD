<?php


     $id=$_GET['id'];

	include("config/lib.php");

	$obj=new Product();

     if($obj->destroy($id)){

        	header("location:index.php");
        }
        else{

        	echo "<script> alert('Sorry..:( Could not delete..')</script>";
        }



	?>
