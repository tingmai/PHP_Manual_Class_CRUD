<!DOCTYPE html>
<html>
<head>
	<title>Php CRUD 1</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

	<div class="container">
		<div class="jumbotron"><h1> Northern City </h1></div>
	</div>

	<div class="container">
		
		<form action="" method="POST" enctype="multipart/form-data">
		  <div class="form-group">
		    <label for="name">Enter Product Name:</label>
		    <input type="text" class="form-control" placeholder="Enter Name" name="name">
		  </div>
		  <div class="form-group">
		    <label for="price">Enter Price:</label>
		    <input type="text" class="form-control" placeholder="Enter Price" name="price">
		  </div>
		   <div class="form-group">
		    <label for="price">Upload Photo:</label>
		    <input type="file" class="form-control" name="photo">
		  </div>
		  
		  <button type="submit" name="submit" class="btn btn-primary"> Save </button>
		</form>


	</div>

</body>
</html>


<?php

	if(isset($_POST["submit"])){


		$name=$_POST['name'];
		$price=$_POST['price'];
		$photo=$_FILES['photo']['name'];


		if($photo)
		{
             if(move_uploaded_file($_FILES['photo']['tmp_name'], 'assets/images/'.$_FILES['photo']['name'])){

             	$photo=$_FILES['photo']['name'];
             }
             else{

             	echo "<script> alert('Sorry..:( Error!!..')</script>";
             }

		}
		else{

			echo "<script> alert('Sorry..:( Error!!..')</script>";
		}

   		include("config/db.php");
   		$stmt = $conn->prepare("INSERT INTO products (name, price, photo)
  		VALUES (:name, :price, :photo)");
  		$stmt->bindParam(':name', $name);
  		$stmt->bindParam(':price', $price);
  		$stmt->bindParam(':photo', $photo);

        if($stmt->execute()){

        	header("location:index.php");
        }
        else{

        	echo "<script> alert('Sorry..:( Could not save..')</script>";
        }




  		$stmt->close();
  		$conn->close();


  }


?>