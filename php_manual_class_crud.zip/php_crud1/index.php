<!DOCTYPE html>
<html>
<head>
	<title> PHP CRUD 1</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

	<div class="container">
		<div class="jumbotron"><h1> Northern City </h1></div>
	</div>
	<div class="container">
		<a href="create.php" class="btn btn-primary"> Create New Product </a>
	</div>

	<div class="container">
		<table class="table table-striped">
			<tr>
				<td> ID </td>
				<td> Name </td>
				<td> Price </td>
				<td> Photo </td>
				<td> Action </td>
			</tr>

			<?php

				include("config/lib.php");

				$obj=new Product();
				$products=$obj->index();

				foreach($products as $product)
				{

					echo "<tr>";
					echo "<td>".$product['id']."</td>";
					echo "<td>".$product['name']."</td>";
					echo "<td>".$product['price']."</td>";
					echo "<td> <img src='assets/images/".$product['photo']."' class='rounded-circle' style='width:100px;height:100px;'> </td>";
					echo "<td>
                            <a href='details.php?id=".$product['id']."' class='btn btn-warning'> Details </a> &nbsp;
							<a href='edit.php?id=".$product['id']."' class='btn btn-success'> Edit </a> &nbsp;
							<a href='delete.php?id=".$product['id']."' class='btn btn-danger'> Delete </a>


					</td>";





				}


			?>



		</table>
	</div>

</body>
</html>